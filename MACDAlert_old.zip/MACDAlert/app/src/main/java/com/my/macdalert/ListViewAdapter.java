package com.my.macdalert;

import android.app.Activity;  
import android.view.LayoutInflater;  
import android.view.View;  
import android.view.ViewGroup;  
import android.widget.ArrayAdapter;  
import android.widget.ImageView;  
import android.widget.TextView;
import java.util.*;  

class stockListAdaptor extends ArrayAdapter<StockMacdDetail>
{  

	private final Activity context;  

    ArrayList<StockMacdDetail> StockList = new ArrayList<StockMacdDetail>();
	public stockListAdaptor(Activity context, ArrayList<StockMacdDetail>  _StockList)
	{  
		super(context, R.layout.cus_stocklist, _StockList);  

		this.context = context;  
		this.StockList = _StockList;  
	}  

	public View getView(int position, View view, ViewGroup parent)
	{  
		LayoutInflater inflater=context.getLayoutInflater();  
		View rowView=inflater.inflate(R.layout.cus_stocklist, null, true);  

	    TextView StockShortcutNameT = (TextView) rowView.findViewById(R.id.stock_name);    
		TextView StockmacdValT = (TextView) rowView.findViewById(R.id.macd_val);  
		TextView StockSigT = (TextView) rowView.findViewById(R.id.macd_sig);

	    String StockS = StockList.get(position).getStockSym();
		Double StockmV = StockList.get(position).getMacdVal();
		int StockSig = StockList.get(position).getMacdSig();

		String MacdSignal = "..";
      
		if (StockSig == 0)
		{
			MacdSignal = "No MACD Signal ....";
			StockmacdValT.setTextColor(R.color.noSignal);
			StockSigT.setTextColor(R.color.noSignal);
		}
		else if (StockSig == 1)
		{
			if (StockmV > 0)
			{
				MacdSignal = "MACD Strong Up ";
				StockmacdValT.setTextColor(R.color.strongUpSignal);
				StockSigT.setTextColor(R.color.strongUpSignal);
			}
			else
			{
				MacdSignal = "MACD Low Up ";
				StockmacdValT.setTextColor(R.color.lowUpSignal);
				StockSigT.setTextColor(R.color.lowUpSignal);
			}
		}
		else if (StockSig == -1)
		{
			if (StockmV < 0)
			{
				MacdSignal = "MACD Strong Down ";
				StockmacdValT.setTextColor(R.color.strongDownSignal);
				StockSigT.setTextColor(R.color.strongDownSignal);
			}
			else
			{
				MacdSignal = "MACD Low Down ";
				StockmacdValT.setTextColor(R.color.lowDownSignal);
				StockSigT.setTextColor(R.color.lowDownSignal);
			}
		}
		
		StockShortcutNameT.setText(StockS);  
		StockmacdValT.setText(StockmV.toString());
		StockSigT.setText(MacdSignal);

		return rowView;  

	};  
}

