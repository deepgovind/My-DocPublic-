package com.my.macdalert;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;

 class RadioDialog  extends DialogFragment{

	 int id = 0;
    AlertPositiveListener alertPositiveListener;
    interface AlertPositiveListener {
        public void onPositiveClick(int position);
    }
	public void setRadioDialogId(int _id){
	  this.id = _id;
    }
    public void onAttach(android.app.Activity activity) {
        super.onAttach(activity);
        try{
            alertPositiveListener = (AlertPositiveListener) activity;
        }catch(ClassCastException e){
            throw new ClassCastException(activity.toString() + " must implement AlertPositiveListener");
        }
    }

    OnClickListener positiveListener = new OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            AlertDialog alert = (AlertDialog)dialog;
            int position = alert.getListView().getCheckedItemPosition();
            alertPositiveListener.onPositiveClick(position);
        }
    };

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Bundle bundle = getArguments();
        int position = bundle.getInt("position");
        AlertDialog.Builder b = new AlertDialog.Builder(getActivity());
		
		if(id == 1){
			b.setTitle("Choose Update Time");
			b.setSingleChoiceItems(SettingStrings.timeUpdate, position, null);
			
		}else if(id == 2){
			b.setTitle("Choose MACD Alert When");
			b.setSingleChoiceItems(SettingStrings.showMacdWhen, position, null);
			
		}
        b.setPositiveButton("OK",positiveListener);
        b.setNegativeButton("Cancel", null);
        AlertDialog d = b.create();

        return d;
    }
}
 class SettingStrings {
    static String[] timeUpdate = new String[]{
        "1min",
        "5min",
        "10min",
        "15min",
        "30min"
    };
	static String[] showMacdWhen = new String[]{
        "All MACD Cross Over",
        "Crossover up",
        "Crossover down",
        "Crossover up > 0",
        "Crossover down < 0",
		"Crossover up > 0 And Down < 0"
    };
}
