package com.my.macdalert;
import android.app.Activity;
import android.widget.TextView;
import android.os.Bundle;
import android.app.*;
import android.view.*;



public class HelpActivity extends Activity {


	private TextView textview1;
	private ActionBar helpActionbar;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.help);
		
		helpActionbar =   getActionBar();
		textview1 = (TextView) findViewById(R.id.helpTextView);
		helpActionbar.setTitle("MACD Alert Help");
		helpActionbar.setDisplayHomeAsUpEnabled(true);
		helpActionbar.setHomeButtonEnabled(true);

		
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				break;
		}
		return true;
	}
}

