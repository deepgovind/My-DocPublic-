package com.my.macdalert;

 class FatchMacdData1
{
}
