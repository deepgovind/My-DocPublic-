package com.my.macdalert;
import android.os.Bundle;
import android.app.Activity;
import android.widget.*;
import android.webkit.*;
import android.view.*;
import android.app.*;

public class ChartView extends Activity
{
	WebView wv;
	ActionBar ab;
	private String stock = "SBIN.NS";
	private String ChartUrl = "https://in.finance.yahoo.com/chart/";
	@Override
	protected void onCreate(Bundle _savedInstanceState)
	{
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.webview);
		wv = (WebView)findViewById(R.id.webview);
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			stock = extras.getString("ChartUrl");
		}
		else{
			show("No Stock");
		}
		
		ab =   getActionBar();
		ab.setTitle(stock);
		ab.setDisplayHomeAsUpEnabled(true);
		ab.setHomeButtonEnabled(true);
		
		ChartUrl += stock;
		
		wv.getSettings().setLoadsImagesAutomatically(true);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		wv.loadUrl(ChartUrl);
		
	}
	public void show(String s){
		Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case android.R.id.home:
				finish();
				break;
		}
		return true;
	}

	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && this.wv.canGoBack()) {
            this.wv.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
	
}
