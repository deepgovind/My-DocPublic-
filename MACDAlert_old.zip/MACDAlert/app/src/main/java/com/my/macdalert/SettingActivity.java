package com.my.macdalert;

import android.app.Activity;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.app.ActionBar;
import android.view.MenuItem;
import java.util.ArrayList;
import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
import com.my.macdalert.RadioDialog.AlertPositiveListener;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.*;


public class SettingActivity extends Activity implements AlertPositiveListener
{
	private ActionBar settingActionbar;
	int position = 0;
	TextView tv,tvMacd;
	public static int id = 0;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState)
	{
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.setting);

		settingActionbar =   getActionBar();
		settingActionbar.setTitle("App Settings");
		settingActionbar.setDisplayHomeAsUpEnabled(true);
		settingActionbar.setHomeButtonEnabled(true);
		tv = (TextView) findViewById(R.id.settingTimeUpdate);
		tvMacd = (TextView) findViewById(R.id.showMacdWhen);
		
		 
		OnClickListener listenerUpdateTime = new OnClickListener() {
			@Override
			public void onClick(View v)
			{
				FragmentManager manager = getFragmentManager();
				RadioDialog alert = new RadioDialog();
				id = 1;
				alert.setRadioDialogId(id);
				Bundle b  = new Bundle();
				b.putInt("position", position);
				alert.setArguments(b);
				alert.show(manager, "alert_dialog_radio");
			}
		};
		
        tv.setOnClickListener(listenerUpdateTime);
		
		OnClickListener listenerShowMacdW = new OnClickListener() {
			@Override
			public void onClick(View v)
			{
				FragmentManager manager = getFragmentManager();
				RadioDialog alert = new RadioDialog();
				id = 2;
				alert.setRadioDialogId(id);
				Bundle b  = new Bundle();
				b.putInt("position", position);
				alert.setArguments(b);
				alert.show(manager, "alert_dialog_radio");
			}
		};
		tvMacd.setOnClickListener(listenerShowMacdW);
		
	
			setrefresht();
		    tv.setText( MainActivity._stockSetting.getUpdateInterval());
		    tvMacd.setText(MainActivity._stockSetting.getshowMacdWhen());
		
		
	}
    public void show(String s){
		Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
	}
	public void setrefresht(){
		
		if(id == 1){
			tv.setText(MainActivity._stockSetting.getUpdateInterval());
		if(MainActivity._stockSetting.getUpdateInterval().equals("1min")){
			MainActivity.refreshMacdTimeMin = 1;
		}else if(MainActivity._stockSetting.getUpdateInterval().equals("5min")){
			MainActivity.refreshMacdTimeMin = 5;
		}else if(MainActivity._stockSetting.getUpdateInterval().equals("10min")){
			MainActivity.refreshMacdTimeMin = 10;
		}else if(MainActivity._stockSetting.getUpdateInterval().equals("15min")){
			MainActivity.refreshMacdTimeMin = 15;
		}else if(MainActivity._stockSetting.getUpdateInterval().equals("30min")){
			MainActivity.refreshMacdTimeMin = 30;
		}
		}else if(id == 2){
			tvMacd.setText(MainActivity._stockSetting.getshowMacdWhen());
		}
	}
	@Override
	public void onPositiveClick(int position)
	{
		this.position = position;
		if(id ==1){
			MainActivity._stockSetting.settUpdateInterval(SettingStrings.timeUpdate[this.position]);
			setrefresht();
		}else if(id ==2){
			MainActivity._stockSetting.setshowMacdWhen(SettingStrings.showMacdWhen[this.position]);
			setrefresht();
		}
		
		saveStockSetting();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case android.R.id.home:
				finish();
				break;
		}
		return true;
	}
	public void deleteArrayList(String key)
	{
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
		editor.remove(key);
		editor.commit();

	}
	public void saveStockSetting()
	{ 
		String key = "StockSetting";
		deleteArrayList(key);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(MainActivity._stockSetting);
        editor.putString(key, json);
        editor.apply();   
    }

    

	
}
 class stockSetting
{
	String notificationToon;
	String updateInterval;
	String showMacdWhen;
	

	public void stockSetting(String _notificationToon, String _updateInterval,String _showMacdWhen)
	{
		this.notificationToon = _notificationToon;
		this.updateInterval = _updateInterval;
		this.showMacdWhen = _showMacdWhen;
	}

	public String getNotificationToon()
	{
		return notificationToon;
	}
	public String getUpdateInterval()
	{
		return updateInterval;
	}
	public void settNotificationToon(String _updateNt)
	{
		this.notificationToon = _updateNt;
	}
	public void settUpdateInterval(String _updateInterval)
	{
		this.updateInterval = _updateInterval;
	}
	public void setshowMacdWhen(String _showMacdWhen)
	{
		this.showMacdWhen = _showMacdWhen;
	}
	public String getshowMacdWhen()
	{
		return showMacdWhen;
	}
	
}
