package com.my.macdalert;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.lang.reflect.Type;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.NotificationManager;

import android.os.Handler;
import android.os.Bundle;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;

import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.app.AlertDialog;
import android.app.ActionBar;
import android.app.SearchManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.widget.Toast;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SimpleCursorAdapter;
import android.widget.SearchView;
import android.widget.CursorAdapter;
import android.widget.ProgressBar;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.MenuItem;
import android.view.Menu;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.DialogInterface;

import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import android.database.MatrixCursor;
import android.database.Cursor;

import android.provider.BaseColumns;

import android.media.RingtoneManager;
import android.media.Ringtone;

import android.support.v4.app.NotificationCompat;



public class MainActivity extends Activity implements OnClickListener
{
   public static int refreshMacdTimeMin = 5;

    ListView listView;
 TextView refreshTimeTextmacd;
    ArrayList<String> stockItemsMacd;
	//ArrayList<String> stocklistItems;
	
	ArrayList<StockMacdDetail> StockDetailList;
	stockListAdaptor mAdapterMacd;
	
	//ArrayAdapter<String> adapter;

	ProgressBar pb;
    Timer timer,timer1;
	
	TimerTask timerTask,timerTask1;

	private ActionBar actionBar;
	final Handler handler = new Handler();
	final Handler handler1 = new Handler();
	public static stockSetting _stockSetting ;
	
	private static final String[] SUGGESTIONS = {
		"SBIN.NS", "UNIONBANK.NS", "HDFC.NS",
		"SBIN.BS", "BABKBARODA.NS", "HDFC.BS"
    };
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		actionBar = getActionBar();
		//actionBar.setDisplayShowTitleEnabled(false);
		actionBar.setDisplayUseLogoEnabled(false);

		refreshTimeTextmacd = (TextView)findViewById(R.id.refreshTime);
	    listView = (ListView) findViewById(R.id.listView);
        pb = (ProgressBar)findViewById(R.id.ProgressBar);
		
		StockDetailList = new ArrayList<StockMacdDetail>();
		//stocklistItems = new ArrayList<String>();
		stockItemsMacd = new ArrayList<String>();

		_stockSetting = new stockSetting();
		_stockSetting.settNotificationToon("Toon");
		_stockSetting.settUpdateInterval("5min");
		_stockSetting.setshowMacdWhen("All MACD Cross Over");
	    
		if(getStockSetting() != null){
			MainActivity._stockSetting =getStockSetting();
			if(_stockSetting.getUpdateInterval().equals("1min")){
				refreshMacdTimeMin = 1;
			}else if(_stockSetting.getUpdateInterval().equals("5min")){
				refreshMacdTimeMin = 5;
			}else if(_stockSetting.getUpdateInterval().equals("10min")){
			   refreshMacdTimeMin = 10;
			}else if(_stockSetting.getUpdateInterval().equals("15min")){
				refreshMacdTimeMin = 15;
			}else if(_stockSetting.getUpdateInterval().equals("30min")){
				refreshMacdTimeMin = 30;
			}
		}

		if (getStockList() != null)
			stockItemsMacd = getStockList();

      //  adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocklistItems);
		mAdapterMacd = new stockListAdaptor(this, StockDetailList);
		
        listView.setAdapter(mAdapterMacd);

		listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

				@Override
				public boolean onItemLongClick(AdapterView<?> parent, View view,
											   int position, long id)
				{
					deleteStockDialog(position);
					return true;
				}
			});		
			
		listView.setOnItemClickListener(new OnItemClickListener() {
            
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						Intent webv = new Intent(getApplicationContext(),ChartView.class);
					webv.putExtra("ChartUrl",stockItemsMacd.get(position));
					startActivity(webv);
					}
			});
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.action_menu, menu);

		final SimpleCursorAdapter mAdapter;
        mAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, null, new String[] {"stock"}, new int[] {android.R.id.text1} , CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

		final SearchView searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
		SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
		//searchView.setMaxWidth(Integer.MAX_VALUE);
		searchView.setSubmitButtonEnabled(true);
		searchView.setSuggestionsAdapter(mAdapter);
        searchView.setIconifiedByDefault(false);

        searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
				@Override
				public boolean onSuggestionClick(int position)
				{
					Cursor cursor = mAdapter.getCursor();
					cursor.moveToPosition(position);
					String selectedItem = cursor.getString(1);
					
					searchView.setQuery("",true);
					searchView.clearFocus();
					
					addStockItem(selectedItem);
					return true;
				}

				@Override
				public boolean onSuggestionSelect(int position)
				{
					return true;
				}             
			});
		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

				@Override
				public boolean onQueryTextSubmit(String s)
				{
					searchView.setQuery("",true);
					searchView.clearFocus();
				    
					addStockItem(s);
					return false;
				}

				@Override
				public boolean onQueryTextChange(String s)
				{
					final MatrixCursor c = new MatrixCursor(new String[]{ BaseColumns._ID, "stock" });
					for (int i=0; i < SUGGESTIONS.length; i++)
					{
						if (SUGGESTIONS[i].toLowerCase().startsWith(s.toLowerCase()))
							c.addRow(new Object[] {i, SUGGESTIONS[i]});
					}
					mAdapter.changeCursor(c);

					return false;
				}
			});

        return super.onCreateOptionsMenu(menu);
    }
	@Override
    public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.action_search:
				// search action
				//Toast.makeText(this,"srarch",Toast.LENGTH_SHORT).show();
				return true;
			case R.id.action_settings:
				Intent seta = new Intent(getApplicationContext(),SettingActivity.class);
				startActivity(seta);
				return true;
			case R.id.action_refresh:
				pb.setVisibility(View.VISIBLE);
				getStockMACD();
				return true;
			case R.id.action_help:
				Intent helpa = new Intent(getApplicationContext(),HelpActivity.class);
				startActivity(helpa);
				return true;
			default:
				return super.onOptionsItemSelected(item);
        }

    }
	public void show(String s)
	{
		Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
	}
	public void deleteStockDialog(final int position)
	{
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
		alertDialogBuilder.setMessage("Are you sure,You wanted to Delete Stock : "+stockItemsMacd.get(position));
		alertDialogBuilder.setPositiveButton("yes", 
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface arg0, int arg1)
				{
					stockItemsMacd.remove(position);
                     pb.setVisibility(View.VISIBLE);
					getStockMACD();

					saveStockList(stockItemsMacd);
					show("Stock Deleted");
				}
			});

		alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which)
				{

				}
			});

		AlertDialog alertDialog = alertDialogBuilder.create();
		alertDialog.show();
	}
	public boolean isStockValid(String stock)
	{
		boolean isv = false;
		if (!stock.isEmpty())
		{
			if (!stockItemsMacd.contains(stock))
			{
				isv = true;
				// TODO: Implement this method
			}
			else
			{
				isv = false;
				show("Stock Already Added ");
			}
		}
		else
		{
			show("Search is empty ! ");
		}

		return isv;
	}
	public void addStockItem(String s)
	{
		if (isStockValid(s))
		{

			s = s.toUpperCase();
			stockItemsMacd.add(s);

			getStockMACD();

			saveStockList(stockItemsMacd);
		}
	}
	public void getStockMACD()
	{
		if (!stockItemsMacd.isEmpty()){
			new FetchMacdData().execute(urlPress(true));
		  }
	}
	public void getStockPrice()
	{
		if (!stockItemsMacd.isEmpty()){
			; //new FatchPriceData().execute(urlPress(false));
		}
	}
	public String urlPress(boolean isMacd)
	{
		String url = null;
		if(isMacd){
			 url = "https://mytyping.000webhostapp.com/stock/StockMacdAlert.php?q=";
			url += String.join(",", stockItemsMacd);
			url += "&interval="+String.valueOf(refreshMacdTimeMin)+"min";
			
			 
		}else{
			url = "https://mobile-query.finance.yahoo.com/v6/finance/quote?lang=en-US&region=US&corsDomain=finance.yahoo.com&symbols=";
			url += String.join(",", stockItemsMacd);
			
		}
		
		return url;
	}
	
	public boolean checkInternetConenction()
	{
		ConnectivityManager connec
			=(ConnectivityManager)getSystemService(getBaseContext().CONNECTIVITY_SERVICE);

		if (connec.getNetworkInfo(0).getState() == 
			android.net.NetworkInfo.State.CONNECTED ||
			connec.getNetworkInfo(0).getState() == 
			android.net.NetworkInfo.State.CONNECTING ||
			connec.getNetworkInfo(1).getState() == 
			android.net.NetworkInfo.State.CONNECTING ||
			connec.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTED)
		{
            
            return true;
		}
		else if (
            connec.getNetworkInfo(0).getState() == 
            android.net.NetworkInfo.State.DISCONNECTED ||
            connec.getNetworkInfo(1).getState() == 
            android.net.NetworkInfo.State.DISCONNECTED)
		{

			return false;
		}
		return false;
	}
	@Override
	public void onClick(View p1)
	{
		// TODO: Implement this method
	}
	public void addNotification(String str, int notifiactionId)
	{
		Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

		NotificationCompat.Builder builder =
			new NotificationCompat.Builder(this)
			.setSmallIcon(R.drawable.ic_launcher)
			.setContentTitle("MACD Crossing")
			.setContentText(str)
			.setSound(soundUri);

		Intent notificationIntent = new Intent(this, MainActivity.class);

		PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
																PendingIntent.FLAG_UPDATE_CURRENT);
		builder.setContentIntent(contentIntent);

		NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		manager.notify(notifiactionId, builder.build());
	}
	@Override
	protected void onResume()
	{
		super.onResume();
		startTimer();
	}
	//Timer
	public void startTimer()
	{
		timer = new Timer();
		timer1 = new Timer();
		initializeTimerTask();
		timer1.schedule(timerTask1, 1000*1*1, 1000*10);
		timer.schedule(timerTask, 1000*1*1, 1000*60*refreshMacdTimeMin);
	}
	public void stoptimertask(View v) {
		if (timer != null) {
			timer.cancel();
			timer = null;
		}
	}

	public void initializeTimerTask() {

		timerTask = new TimerTask() {
			public void run() {

				handler.post(new Runnable() {
						public void run() {
							getStockMACD();
							show("2");
						}
					});
			}
		};
		timerTask1 = new TimerTask() {
			public void run() {

				handler1.post(new Runnable() {
						public void run() {
							show("1");
							
						}
					});
			}
		};
	}
	public void deleteArrayList(String key)
	{
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
		editor.remove(key);
		editor.commit();

	}
	public void saveStockList(ArrayList<String> list)
	{ 
	    String key = "StockList";
		deleteArrayList(key);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(key, json);
        editor.apply();   
    }

    public ArrayList<String> getStockList()
	{
		String key = "StockList";
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        return gson.fromJson(json, type);
    }
	public  stockSetting getStockSetting()
	{
		String key = "StockSetting";
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.getApplicationContext());
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<stockSetting>() {}.getType();
        return gson.fromJson(json, type);
    }
	///////////////
	
	//////////////
	//AsyncTask
    private class FetchMacdData extends AsyncTask<String,String,String>
	{
        @Override
        protected void onPreExecute()
		{
			//pb.setVisibility(View.VISIBLE);
        }
		public  String getHttpData(String stringUrl)
		{

			BufferedReader reader = null;
			try
			{
				URL url = new URL(stringUrl);
				HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				StringBuilder sb = new StringBuilder();
				InputStreamReader is = new InputStreamReader(connection.getInputStream());
				reader = new BufferedReader(is);
				String line;
				while ((line = reader.readLine()) != null)
				{
					sb.append(line).append("\n");
				}

				return sb.toString();
			}
			catch (Exception e)
			{
				//e.printStackTrace();
				return "{  \"data\": [{\"Stock\": \"Connection Data Slow\",\"MACD\": \"0\",\"MACDVal\":\"0\"}] }";
				//return null;
			}
			finally
			{
				try
				{
				  if(reader != null)
					 reader.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}

		}
		public boolean isJSONValid(String test)
		{
			try
			{
				new JSONObject(test);
			}
			catch (JSONException ex)
			{
				try
				{
					new JSONArray(test);
				}
				catch (JSONException ex1)
				{
					return false;
				}
			}
			return true;
		}
		public  ArrayList<StockMacdDetail>  Parse(String json)
		{
			String StockSortName;
			int MACDStatus;
			Double MacdVal;
			ArrayList<StockMacdDetail> stockList = new ArrayList<StockMacdDetail>();

			if (!isJSONValid(json))
			{
				addNotification("JSON Not valid", 0);
				return stockList;
			}

			try
			{
				JSONObject object = new JSONObject(json);
				JSONArray jsonArray = object.getJSONArray("data");

				for (int i = 0;i < jsonArray.length();i++)
				{
					JSONObject jb = jsonArray.getJSONObject(i);
					StockSortName = jb.getString("Stock");
					MACDStatus = jb.getInt("MACD");
					MacdVal = jb.getDouble("MACDVal");

					
					stockList.add(new StockMacdDetail(StockSortName, MACDStatus,MacdVal));
				}
				return stockList;
			}
			catch (JSONException e)
			{
				e.printStackTrace();
				return null;
			} 
		}

        @Override
        protected String doInBackground(String... params)
		{
			String data;
			if (checkInternetConenction())
			{
				data = getHttpData(urlPress(true));
			}
			else
			{
				data = "{  \"data\": [{\"Stock\": \"No Internet Connection\",\"MACD\": \"0\",\"MACDVal\":\"0\"}] }";
			}

			return data;
        }

        @Override
        protected void onPostExecute(String s)
		{
			pb.setVisibility(View.INVISIBLE);
			ArrayList<StockMacdDetail>  arl = new ArrayList<StockMacdDetail>();
			arl = Parse(s);
			
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss a");
			String strDate = simpleDateFormat.format(calendar.getTime());

			refreshTimeTextmacd.setText(" Last Refreshed :  "+strDate);
			
			if (!arl.isEmpty())
			{
				//if (!stocklistItems.isEmpty())
				//	stocklistItems.clear();
				int id = 0;
					String showMacdW = _stockSetting.getshowMacdWhen();
				if(showMacdW.equals("All MACD Cross Over"))
					  id = 1;
			    else if(showMacdW.equals("Crossover up"))
					id = 2;
				else if(showMacdW.equals("Crossover down"))
					id = 3;
				else if(showMacdW.equals("Crossover up > 0"))
					id = 4;
				else if(showMacdW.equals("Crossover down < 0"))
					id = 5;
				else if(showMacdW.equals("Crossover up > 0 And Down < 0"))
					id = 6;
				
				
				if (!StockDetailList.isEmpty())
					StockDetailList.clear();
					
				
				for (int i=0;i < arl.size();i++)
				{
					String st = arl.get(i).getStockSym();
					int maS = arl.get(i).getMacdSig();
                    Double macdV = arl.get(i).getMacdVal();
					
					
					String fs = st;
					if(maS == 1){
						if(macdV > 0){
							if(id == 1 || id == 4 || id == 6 || id ==2)
							 fs += "  MACD Strong Up "+strDate;
						}
						else{
							if(id == 1 || id == 2)
							  fs += "  MACD Low Up "+strDate;
						}
						addNotification(fs, i + 1);
					}else if(maS == -1){
						addNotification(fs, i + 1);
						if(macdV < 0){
							if(id == 1 || id == 3 || id == 5 || id == 6)
							  fs += "  MACD Strong Down "+strDate;
						}
						else{
							if(id == 1 || id == 3)
							  fs += "  MACD Low Down "+strDate;
						}
						addNotification(fs, i + 1);
					}
				
					StockDetailList.add(new StockMacdDetail(st,maS,macdV));
					mAdapterMacd.notifyDataSetChanged();
					
				}
			}
		}
    }
}

