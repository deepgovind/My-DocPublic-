package com.my.macdalert;
class StockMacdDetail
{
	String stock;
	int macdSig;
	Double macdVal;
	public StockMacdDetail(String st, int _macdSig, Double _macdVal)
	{
		this.stock = st;
		this.macdSig  = _macdSig;
		this.macdVal = _macdVal;
	}
	public String getStockSym()
	{
		return stock;
	}
	public int getMacdSig()
	{
		return macdSig;
	}
	public Double getMacdVal()
	{
		return macdVal;
	}
}
class StockPriceDetail
{
	String stock;
	int macdSig;
	Double macdVal;
	public StockPriceDetail(String st, int _macdSig, Double _macdVal)
	{
		this.stock = st;
		this.macdSig  = _macdSig;
		this.macdVal = _macdVal;
	}
	public String getStockSym()
	{
		return stock;
	}
	public int getMacdSig()
	{
		return macdSig;
	}
	public Double getMacdVal()
	{
		return macdVal;
	}
}
class stock1
{
	String stock;
	int macdSig;
	Double macdVal;
	public stock1(String st, int _macdSig, Double _macdVal)
	{
		this.stock = st;
		this.macdSig  = _macdSig;
		this.macdVal = _macdVal;
	}
	public String getStockSym()
	{
		return stock;
	}
	public int getMacdSig()
	{
		return macdSig;
	}
	public Double getMacdVal()
	{
		return macdVal;
	}
}
